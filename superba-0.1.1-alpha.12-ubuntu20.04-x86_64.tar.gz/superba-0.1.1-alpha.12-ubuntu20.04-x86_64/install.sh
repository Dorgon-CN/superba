#!/bin/bash
# Superba v0.1.1-alpha.12 (Ubuntu 20.04 自编译版) 一键安装
set -e
cd "$(dirname "$0")"
mkdir -p ~/.local/bin ~/.local/share/icons ~/.local/share/applications
cp superba spb superba-router ~/.local/bin/
chmod +x ~/.local/bin/superba ~/.local/bin/spb ~/.local/bin/superba-router
cp superba.png ~/.local/share/icons/superba.png
cat > ~/.local/share/applications/superba.desktop <<DESKTOP
[Desktop Entry]
Type=Application
Name=Superba
Comment=OpenAI Codex 启动器 / 配置切换器
Exec=$HOME/.local/bin/superba
Icon=superba
Terminal=false
Categories=Development;Utility;
DESKTOP
echo "安装完成！应用菜单搜 Superba，或命令行运行: superba"
